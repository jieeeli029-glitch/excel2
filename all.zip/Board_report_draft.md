## Purpose and scope

Recommend capital and reinsurance for Wattle Mutual’s Regional Events Protection portfolio against the board’s 1% ultimate ruin target. All dollar figures below are millions; premiums are annual. The assessment uses a classical surplus model with continuous premium income, 14 claims per year, and independent exponential claim sizes with median $3.50m. It excludes operating expenses, investment returns and recovery delays. The target concerns ruin at any future time, not merely a negative year-end balance.

## Evidence

Expected annual claims are $70.6921m against premium income of $91.8079m, producing positive expected drift of $21.1158m. Positive drift supports survival but does not make current capital adequate: at $21.50m, exact ultimate ruin probability is 28.9187%. The exact exponential-claims formula gives an unrounded capital requirement of $95.3641m, rounded upward to $96m.

The supplied deterministic stress path becomes insolvent at year 0.12, reaching a minimum surplus of negative $1.2366m, despite closing at positive $30.1504m. An extra $1.236553m available initially prevents ruin on that path alone; this is liquidity evidence, not an estimated ruin probability or a substitute for the $96m requirement.

The two budget-exhausting reinsurance contracts each cost $13.7712m, exactly 15% of current premium, and cede expected annual claims of $9.3644m. Proportional retention is 86.7532%; excess-of-loss retention is $10.2070m per claim. Both leave net premium of $78.0367m, expected retained claims of $61.3277m and positive drift of $16.7090m.

For the same 1% objective, exact capital indications are $96m without reinsurance and $90m with proportional cover. Excess-of-loss requires sufficient capital of $72m using a Lundberg upper bound. Its adjustment coefficient is approximately 0.064583; the verified conservative coefficient 0.064 gives a bound of 0.9972% at $72m. This is a guarantee within the model, not an exact minimum. Comparing every contract using Lundberg bounds instead gives $102m, $95m and $72m respectively. Thus differences reflect both contracts and methods. Although the exact excess-of-loss minimum remains unknown, it cannot exceed $72m, already below the proportional exact minimum of $90m.

A 3% higher severity median raises the exact uninsured capital indication to $110m with premium unchanged, or $99m after restoring the 77% loss ratio through repricing. Both retain positive expected drift. The $110m case is more relevant before repricing becomes effective.

The alternative one-year utility model prefers 86.6667% retention, only 0.08658 percentage points below the proportional design. Its different pricing principle produces premium of $11.3331m, or 12.3444% of gross income, within budget. Similar retention does not establish similar ultimate solvency: the objective, horizon and reinsurer’s pricing differ.

## Recommendation

Raise uninsured capital to at least $96m, adding $74.50m to current capital. Prefer the cost-matched excess-of-loss contract; once binding cover and prompt recoveries are verified, adopt a baseline model capital floor of $72m, still $50.50m above current capital. Confirm counterparties, exclusions and renewal terms before releasing capital. Prioritise the board’s ultimate ruin objective over the one-year utility result. Budget exhaustion is a comparison constraint, not proof of optimal spending: cover reduces expected drift, and marginal benefit requires further analysis.

## Limitations and monitoring

The most consequential limitation is unvalidated independence and stability: clustered events or heavier severity tails could invalidate the quoted assurances. Diagnose arrivals using monthly count dispersion and serial dependence; diagnose severity using an exponential quantile plot and tail-exceedance rates. These checks detect departures, not prove assumptions.

Proposed management triggers are a variance-to-mean count ratio above 1.5 over 36 months, or a median above $3.605m or over 10% of the latest 100 claims exceeding $15.1267m. Any trigger freezes capital releases and prompts refitting and a new capital assessment; reassess uninsured capital at $110m if the 3% severity scenario is supported before repricing. Recovery delays exceeding 30 days trigger a liquidity top-up review. These thresholds are proposed controls requiring calibration, not observed findings. Recalculate retained-loss capital after any material pricing, coverage or parameter change.
