# Excel 公式与缓存值核验

所有 24 个黄色格均使用可见公式。以下值来自 LibreOffice 实际重算，并已与 60 位精度独立计算核对。
原模板非黄色格的内容、公式和样式不变；灰色公式的计算缓存已刷新。这不是修改原公式。

| 工作表 | 单元格 | 可见公式 | 重算值 |
|---|---|---|---|
| Evidence_Ledger | C7 | `=4*H7` | 14 |
| Evidence_Ledger | C8 | `=LN(2)/H8` | 0.198042051588556 |
| Evidence_Ledger | C9 | `=C7/C8` | 70.6920570035592 |
| Evidence_Ledger | C10 | `=C9/H9` | 91.8078662383886 |
| Evidence_Ledger | C11 | `=C10-C9` | 21.1158092348294 |
| Evidence_Ledger | D17 | `=-LN(1-95%)/$C$8` | 15.1267483321058 |
| Evidence_Ledger | D18 | `=-LN(1-97.5%)/$C$8` | 18.6267483321058 |
| Evidence_Ledger | E17 | `=E16+C17-D17` | 10.9636449798137 |
| Evidence_Ledger | E18 | `=E17+C18-D18` | -1.2365527156049 |
| Evidence_Ledger | E19 | `=E18+C19-D19` | 20.9696498311439 |
| Evidence_Ledger | E20 | `=E19+C20-D20` | 30.1504364549828 |
| Evidence_Ledger | B26 | `=MAX(0,-B23)` | 1.2365527156049 |
| Decision_Dashboard | C7 | `=Evidence_Ledger!$H$9*EXP(-C9*Evidence_Ledger!$H$10)` | 0.289186720084083 |
| Decision_Dashboard | C8 | `=ROUNDUP(LN(Evidence_Ledger!$H$9/Evidence_Ledger!$H$11)/C9,0)` | 96 |
| Decision_Dashboard | C9 | `=Evidence_Ledger!$C$8-Evidence_Ledger!$C$7/Evidence_Ledger!$C$10` | 0.0455496718653678 |
| Decision_Dashboard | C10 | `=ROUNDUP(LN(Evidence_Ledger!$H$9*(1+3%)/Evidence_Ledger!$H$11)/(Evidence_Ledger!$C$8/(1+3%)-Evidence_Ledger!$C$7/Evidence_Ledger!$C$10),0)` | 110 |
| Decision_Dashboard | C11 | `=ROUNDUP((1+3%)*LN(Evidence_Ledger!$H$9/Evidence_Ledger!$H$11)/C9,0)` | 99 |
| Decision_Dashboard | C16 | `=Evidence_Ledger!$H$13*Evidence_Ledger!$C$10` | 13.7711799357583 |
| Decision_Dashboard | C17 | `=1-Evidence_Ledger!$H$12*C16/Evidence_Ledger!$C$9` | 0.867532467532468 |
| Decision_Dashboard | C18 | `=-LN(1-C17)/Evidence_Ledger!$C$8` | 10.2070125276377 |
| Decision_Dashboard | C19 | `=ROUNDUP(LN((Evidence_Ledger!$C$9-Evidence_Ledger!$H$12*C16)/(Evidence_Ledger!$C$10-C16)/Evidence_Ledger!$H$11)/(Evidence_Ledger!$C$8/C17-Evidence_Ledger!$C$7/(Evidence_Ledger!$C$10-C16)),0)` | 90 |
| Decision_Dashboard | C20 | `=ROUNDUP(-LN(Evidence_Ledger!$H$11)/0.064,0)` | 72 |
| Decision_Dashboard | C25 | `=Evidence_Ledger!$H$15/(Evidence_Ledger!$H$15+Evidence_Ledger!$H$14)` | 0.866666666666667 |
| Decision_Dashboard | C26 | `=Evidence_Ledger!$C$7/Evidence_Ledger!$H$15*(Evidence_Ledger!$C$8/(Evidence_Ledger!$C$8-Evidence_Ledger!$H$15*(1-C25))-1)` | 11.3331381996076 |

## 灰色汇总核验

| 单元格 | 结果 |
|---|---|
| Evidence_Ledger!B23 | -1.2365527156049 |
| Evidence_Ledger!B24 | 0.12 |
| Evidence_Ledger!B25 | Yes |

说明：C20 中的 0.064 是附录 Q4 给出符号检验的保守系数，并非未解释的中间数。
3%、95%、97.5%、每年四季度、ln(2) 均直接来自题目或指数分布的定义。
未使用模拟、宏、VBA、Solver、Goal Seek、加载项、What-If Data Tables、隐藏计算或外部链接。
工作簿只含原来的两个工作表。未添加说明页、批注、命名公式或额外计算格。